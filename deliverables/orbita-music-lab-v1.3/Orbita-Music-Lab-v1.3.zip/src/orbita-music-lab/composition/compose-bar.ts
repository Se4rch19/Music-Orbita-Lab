import { createPrng } from "../core/prng.ts";
import { clamp01, clampMidi, nearestMidi } from "../core/pitch.ts";
import type {
  BarScore,
  BassRole,
  ChordVoicing,
  GameMode,
  PercHitKind,
  PhraseBarPlan,
  PhrasePlan,
  ScoreNote,
  SectionId,
  VoiceName,
} from "../core/types.ts";
import { TICKS_PER_BAR } from "../core/types.ts";
import { chordTonesMidi, isChordTone } from "../theory/chords.ts";
import { pickVariation, realizeMotif, variationForStage, varyMotif, varyMotifComposed } from "../theory/motifs.ts";
import { nearestScaleMidi } from "../theory/scales.ts";
import { chordAtBar, modeModifiers, sectionAtBar, type SessionIdentity } from "./session.ts";
import {
  chooseResolvedPickup,
  commonToneMidis,
  consonantPickupInterval,
  isBeatTick,
  isHarshAgainstChord,
  nearestChordTone,
  polishPhrase,
  tensionPolicyFor,
} from "../theory/harmonic-role.ts";
import type { TensionPolicy } from "../theory/harmonic-role.ts";
import { grammarFor } from "./grammar.ts";
import { barPlanFrom, phrasePlanFor, summarizePhrase } from "./phrase.ts";

export type ComposeContext = {
  session: SessionIdentity;
  barIndex: number;
  intensity: number;
  combo: number;
  mode: GameMode;
  previousVoicing?: ChordVoicing;
  pickupContour?: number[];
  forceSection?: SectionId;
  incomingVoicing?: ChordVoicing;
  polish?: boolean;
  /** v1.3 composer. Default on. Pass false to hear the v1.2 bar writer. */
  composer?: boolean;
};

const SECTION_BASE: Record<SectionId, number> = {
  INTRO: 0.4,
  A: 0.64,
  A_VARIATION: 0.72,
  B: 0.7,
  BUILD: 0.9,
  PEAK: 1,
  RECOVERY: 0.38,
  TRANSITION: 0.24,
};

const PRIORITY: Record<VoiceName, number> = {
  pickup: 10,
  event: 9,
  lead: 8,
  bass: 7,
  kick: 6,
  pluck: 6,
  pad: 5,
  bell: 4,
  snare: 4,
  arp: 3,
  hat: 2,
  click: 2,
  noise: 1,
};

export function composeBar(ctx: ComposeContext): BarScore {
  const { session } = ctx;
  const composer = ctx.composer !== false;
  const sectionInfo = ctx.forceSection
    ? { id: ctx.forceSection, localBar: ctx.barIndex }
    : sectionAtBar(session, ctx.barIndex);
  const section = sectionInfo.id;
  const voicing = chordAtBar(session, section, sectionInfo.localBar, ctx.previousVoicing?.midi);
  const rng = createPrng(`${session.variationSeed}::bar:${ctx.barIndex}::${section}`);
  const mode = modeModifiers(ctx.mode);
  const energy = clamp01(SECTION_BASE[section] * 0.48 + ctx.intensity * 0.74);
  const density = clamp01(Math.max(0.28, energy * mode.density));
  const phrase: PhrasePlan | null =
    composer && section !== "TRANSITION" ? phrasePlanFor(session, ctx.barIndex, ctx.intensity, ctx.combo, ctx.forceSection) : null;
  const plan: PhraseBarPlan | null = phrase ? barPlanFrom(phrase, sectionInfo.localBar) : null;
  const percAmt = clamp01(
    0.28 + energy * mode.percussion * (session.theme.densityRange[0] + density * 0.9),
  );
  const notes: ScoreNote[] = [];
  const isFill = plan
    ? plan.fill
    : sectionInfo.localBar === 7 && energy > 0.48 && rng.chance(0.62 + ctx.intensity * 0.28);
  const world = session.themeId;
  const polish = ctx.polish !== false;
  const policy = tensionPolicyFor(world, session.scale, {
    anomaly: ctx.mode === "anomaly",
    tension: session.dna.tension,
  });
  const chordChanged = Boolean(
    ctx.previousVoicing &&
      ctx.previousVoicing.pitchClasses.join(",") !== voicing.pitchClasses.join(","),
  );

  if (section === "TRANSITION") {
    addTransitionPivot(notes, voicing, ctx.incomingVoicing, session, chordChanged);
  } else {
    addPad(notes, voicing, density, mode.space, section, ctx.intensity, world, chordChanged, plan);
    addBass(notes, voicing, session, density, rng, section, mode.pulse, ctx.intensity, polish, plan);
    addPulse(notes, voicing, session, density, section, ctx.intensity, plan);
    addShimmer(notes, voicing, world, section, ctx.intensity, ctx.barIndex, polish);
    addPercussion(notes, session, plan ? plan.percDensity : percAmt, rng, isFill, mode, ctx.intensity, world, section, composer);
    addMelody(notes, voicing, session, ctx, section, density, rng, policy, polish, plan, sectionInfo.localBar);
    addArp(notes, voicing, session, density, rng, ctx.combo, section, ctx.intensity, plan);
    const echo =
      ctx.pickupContour &&
      ctx.pickupContour.length >= 3 &&
      (plan ? plan.role === "response" && ctx.combo >= 8 : rng.chance(0.3 + Math.min(0.4, ctx.combo / 28)));
    if (echo) {
      addPickupEcho(notes, voicing, session, ctx.pickupContour!, rng, policy, polish);
    }
    const wantCounter = plan
      ? plan.counterActive
      : section === "PEAK" ||
        (section === "BUILD" && ctx.intensity > 0.45) ||
        (section === "B" && ctx.combo >= 12 && ctx.intensity > 0.55);
    if (wantCounter && (plan || rng.chance(0.82))) {
      addCounter(notes, voicing, session, ctx, rng, policy, polish, plan);
    }
  }

  let scored = notes.filter((n) => Number.isFinite(n.midi) && n.velocity > 0 && n.durationTicks > 0);
  if (polish && section !== "TRANSITION") {
    scored = polishPhrase(scored, voicing, session.tonicPc, session.scale, policy, ["lead", "pluck", "bell", "pickup"]);
    scored = polishPhrase(scored, voicing, session.tonicPc, session.scale, policy, ["bass"]);
  }
  for (const note of scored) {
    if (note.priority === undefined) note.priority = priorityFor(note.voice, section, world);
    if (composer) note.velocity = humanizeVel(note.velocity, note.tick);
  }

  return {
    barIndex: ctx.barIndex,
    section,
    chord: voicing,
    notes: scored,
    isFill,
    phrase: phrase ? summarizePhrase(session, phrase, sectionInfo.localBar) : undefined,
  };
}

function humanizeVel(value: number, tick: number): number {
  return clamp01(value * (0.97 + ((tick * 3) % 5) * 0.006));
}

function priorityFor(voice: VoiceName, section: SectionId, world: SessionIdentity["themeId"]): number {
  if (world === "glaciar" && voice === "bell") return 8;
  if (world === "durazno" && voice === "pluck" && section !== "INTRO") return 8;
  if (voice === "bell" && (section === "PEAK" || section === "BUILD")) return 3;
  return PRIORITY[voice];
}

function addTransitionPivot(
  notes: ScoreNote[],
  outgoing: ChordVoicing,
  incoming: ChordVoicing | undefined,
  session: SessionIdentity,
  _chordChanged: boolean,
) {
  const dest = incoming ?? outgoing;
  const tones = incoming ? commonToneMidis(outgoing, incoming, session.theme.padRegister) : outgoing.midi.slice(0, 2);
  const vel = 0.72;
  for (let i = 0; i < Math.min(2, tones.length); i++) {
    notes.push({
      tick: 0,
      durationTicks: 12,
      midi: tones[i]!,
      velocity: vel * (i === 0 ? 1 : 0.82),
      voice: "pad",
      pan: i === 0 ? -0.18 : 0.18,
      priority: 5,
      layer: "harmony",
    });
  }
  notes.push({
    tick: 0,
    durationTicks: 8,
    midi: Math.max(36, outgoing.bassMidi),
    velocity: 0.78,
    voice: "bass",
    priority: 7,
    layer: "bass",
  });
  notes.push({
    tick: 8,
    durationTicks: 8,
    midi: Math.max(36, dest.bassMidi),
    velocity: 0.82,
    voice: "bass",
    priority: 7,
    layer: "bass",
  });
  const pivot = tones[0] ?? dest.rootMidi;
  notes.push({
    tick: 4,
    durationTicks: 6,
    midi: nearestMidi((dest.pitchClasses[2] ?? dest.rootMidi) % 12, Math.min(84, pivot + 12)),
    velocity: 0.5,
    voice: "bell",
    pan: 0.12,
    priority: 4,
    layer: "atmosphere",
  });
}

function addPad(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  density: number,
  _space: number,
  section: SectionId,
  intensity: number,
  world: SessionIdentity["themeId"],
  chordChanged: boolean,
  plan: PhraseBarPlan | null,
) {
  const vel = clamp01(
    0.84 +
      density * 0.14 +
      (section === "PEAK" ? 0.06 : 0) +
      (world === "glaciar" ? 0.06 : 0),
  );
  const hold = chordChanged ? 14 : world === "glaciar" || section === "RECOVERY" ? 16 : 15;
  const triadOnly = plan?.tensionOwner === "lead";
  const count = triadOnly ? Math.min(3, voicing.midi.length) : section === "INTRO" && intensity < 0.28 ? 2 : 3;
  const tones = voicing.midi.slice(0, count);
  for (let i = 0; i < tones.length; i++) {
    notes.push({
      tick: 0,
      durationTicks: hold,
      midi: tones[i]!,
      velocity: vel * (i === 0 ? 1 : i === 1 ? 0.9 : 0.78),
      voice: "pad",
      pan: (i / Math.max(1, tones.length - 1) - 0.5) * 0.48,
      priority: 5,
      layer: "harmony",
    });
  }
  if ((section === "PEAK" || (world === "eclipse" && intensity >= 0.62 && section !== "INTRO")) && tones[0]) {
    const sub = tones[0] - 12;
    if (sub >= 43) {
      notes.push({
        tick: 0,
        durationTicks: hold,
        midi: sub,
        velocity: vel * 0.58,
        voice: "pad",
        pan: 0,
        priority: 4,
        layer: "harmony",
      });
    }
  }
}

function addBass(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  density: number,
  rng: ReturnType<typeof createPrng>,
  section: SectionId,
  pulse: number,
  intensity: number,
  polish: boolean,
  plan: PhraseBarPlan | null,
) {
  const role: BassRole = plan?.bassRole ?? (session.themeId === "durazno" ? "groove-cell" : "root-motion");
  const useAlt = (section === "A_VARIATION" || section === "B" || intensity > 0.55) && session.theme.bassPatterns[1];
  const pattern = (useAlt ? session.theme.bassPatterns[1] : session.theme.bassPatterns[0])!;
  const steps = pattern.steps;
  const root = Math.max(36, voicing.bassMidi);
  const fifth = nearestMidi((voicing.pitchClasses[2] ?? (root + 7)) % 12, root + 7);
  const third = nearestMidi((voicing.pitchClasses[1] ?? root) % 12, root + 4);
  const octave = Math.min(51, root + 12);
  const approach = nearestScaleMidi(root - 2, session.tonicPc, session.scale);
  const driving = session.themeId === "durazno" || session.themeId === "eclipse";

  const push = (tick: number, midi: number, dur: number, vel: number) => {
    notes.push({
      tick,
      durationTicks: dur,
      midi: clampMidi(Math.max(36, midi)),
      velocity: vel,
      voice: "bass",
      priority: 7,
      layer: "bass",
    });
  };

  if (role === "pedal" || (section === "INTRO" && intensity < 0.28 && !driving && !plan)) {
    push(0, root, 15, 0.92);
    push(8, fifth, 6, 0.72);
    return;
  }

  if (role === "octave-pulse") {
    push(0, root, 5, 0.94);
    push(4, root, 3, 0.78);
    push(8, octave, 5, 0.88);
    push(12, fifth, 3, 0.74);
    return;
  }

  if (role === "inversion") {
    push(0, third, 8, 0.86);
    push(8, root, 6, 0.9);
    return;
  }

  for (let tick = 0; tick < TICKS_PER_BAR; tick++) {
    let code = steps[tick % steps.length] ?? 0;
    if (code === 0) continue;
    if (!driving && density < 0.32 && tick % 8 !== 0) continue;
    if (!driving && pulse < 0.5 && tick % 4 !== 0 && code !== 1) continue;
    if (section === "RECOVERY" && tick % 8 !== 0) continue;
    if (role === "root-motion" && isBeatTick(tick) && (code === 3 || code === 5)) code = 1;
    if (polish && isBeatTick(tick) && code === 3) code = 1;
    let midi = root;
    if (code === 2) midi = fifth;
    else if (code === 3) midi = approach;
    else if (code === 4) midi = octave;
    else if (code === 5) midi = third;
    if (polish && code === 3 && (isBeatTick(tick) || isHarshAgainstChord(midi, voicing))) midi = fifth;
    if (plan && isBeatTick(tick) && !isChordTone(midi, voicing)) midi = root;
    push(tick, Math.max(36, midi), code === 1 && tick % 4 === 0 ? 5 : 3, 0.86 + (tick === 0 ? 0.1 : 0) * pulse);
  }
}

function addPulse(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  density: number,
  section: SectionId,
  intensity: number,
  plan: PhraseBarPlan | null,
) {
  if (section === "TRANSITION") return;
  if (plan && !plan.pulseActive) return;
  const world = session.themeId;
  if (section === "RECOVERY" && world !== "durazno") {
    notes.push({
      tick: 0,
      durationTicks: 4,
      midi: nearestMidi((voicing.pitchClasses[2] ?? voicing.rootMidi) % 12, session.theme.melodyRegister[0] - 3),
      velocity: 0.42,
      voice: world === "glaciar" ? "bell" : "pluck",
      pan: -0.18,
      priority: 3,
      layer: "atmosphere",
    });
    return;
  }
  if (intensity < 0.12 && world === "menta") return;
  const fifth = nearestMidi((voicing.pitchClasses[2] ?? voicing.rootMidi) % 12, session.theme.melodyRegister[0] - 5);
  const step = world === "lavanda" ? 3 : world === "glaciar" ? 8 : 4;
  const vel = 0.5 + intensity * 0.22 + (world === "durazno" ? 0.1 : 0);
  for (let tick = 0; tick < 16; tick += step) {
    notes.push({
      tick,
      durationTicks: world === "glaciar" ? 4 : 2,
      midi: fifth,
      velocity: vel,
      voice: world === "glaciar" ? "bell" : world === "lavanda" ? "arp" : "pluck",
      pan: tick % 8 === 0 ? -0.24 : 0.24,
      priority: 3,
      layer: world === "lavanda" ? "arp" : "atmosphere",
    });
  }
}

function addShimmer(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  world: SessionIdentity["themeId"],
  section: SectionId,
  intensity: number,
  barIndex: number,
  polish: boolean,
) {
  if (section === "TRANSITION") return;
  const topRaw = Math.min(96, (voicing.midi[voicing.midi.length - 1] ?? voicing.rootMidi + 12) + (world === "glaciar" ? 12 : 7));
  const top = polish ? nearestChordTone(topRaw, voicing) : topRaw;
  if (world === "glaciar") {
    notes.push({
      tick: 0,
      durationTicks: 10,
      midi: top,
      velocity: 0.7 + (section === "PEAK" ? 0.1 : 0),
      voice: "bell",
      pan: 0.32,
      priority: 8,
      layer: "atmosphere",
    });
    if (section !== "INTRO" && section !== "RECOVERY") {
      const second = polish ? nearestChordTone(Math.max(72, top - 7), voicing) : Math.max(72, top - 7);
      notes.push({
        tick: 8,
        durationTicks: 5,
        midi: second,
        velocity: 0.5,
        voice: "bell",
        pan: -0.28,
        priority: 4,
        layer: "atmosphere",
      });
    }
    return;
  }
  if (world === "lavanda" && (barIndex % 2 === 0 || intensity > 0.4)) {
    notes.push({
      tick: 3,
      durationTicks: 4,
      midi: top,
      velocity: 0.48,
      voice: "bell",
      pan: 0.4,
      priority: 3,
      layer: "atmosphere",
    });
  }
  if (world === "menta" && section !== "INTRO" && barIndex % 4 === 0) {
    const sparkle = polish ? nearestChordTone(Math.min(88, voicing.rootMidi + 19), voicing) : Math.min(88, voicing.rootMidi + 19);
    notes.push({
      tick: 8,
      durationTicks: 6,
      midi: sparkle,
      velocity: 0.46,
      voice: "bell",
      pan: 0.2,
      priority: 3,
      layer: "atmosphere",
    });
  }
}

function addPercussion(
  notes: ScoreNote[],
  session: SessionIdentity,
  percAmt: number,
  rng: ReturnType<typeof createPrng>,
  isFill: boolean,
  mode: ReturnType<typeof modeModifiers>,
  intensity: number,
  world: SessionIdentity["themeId"],
  section: SectionId,
  composer: boolean,
) {
  if (section === "TRANSITION") return;
  const pattern = session.theme.percPatterns[0]!;
  const rotate = section === "B" ? 2 : 0;
  const at = (arr: number[], tick: number) => arr[(tick + rotate) % arr.length] ?? 0;
  const floor =
    world === "durazno" || world === "eclipse"
      ? 0.42
      : world === "glaciar"
        ? 0.24
        : world === "lavanda"
          ? 0.3
          : 0.26;
  const amount = Math.max(floor, percAmt);
  if (section === "RECOVERY") {
    notes.push({ tick: 0, durationTicks: 2, midi: 92, velocity: 0.5, voice: "click", priority: 2, layer: "percussion" });
    if (world === "glaciar" || world === "lavanda") {
      notes.push({ tick: 8, durationTicks: 2, midi: 91, velocity: 0.48, voice: "bell", priority: 3, layer: "atmosphere" });
    }
    if (world === "durazno" || world === "eclipse") {
      notes.push({ tick: 0, durationTicks: 3, midi: 36, velocity: 0.7, voice: "kick", priority: 6, layer: "percussion" });
      notes.push({ tick: 8, durationTicks: 2, midi: 48, velocity: 0.5, voice: "snare", priority: 4, layer: "percussion" });
    }
    return;
  }

  const voiceFor = (kind: PercHitKind): VoiceName => {
    if (kind === "kick") return "kick";
    if (kind === "snare") return "snare";
    if (kind === "hat" || kind === "hatOpen") return "hat";
    return "click";
  };

  const place = (kind: PercHitKind, tick: number, step: number) => {
    if (step <= 0) return;
    const threshold = kind === "hat" ? 0.1 : kind === "kick" ? 0.03 : 0.12;
    if (amount < threshold && step < 2 && world !== "durazno" && world !== "eclipse") return;
    if (kind === "hat" && intensity < 0.18 && world === "menta") return;
    if (kind === "hat" && section === "INTRO" && intensity < 0.35 && world !== "durazno") return;
    if (kind === "hat" && intensity < 0.32 && step < 2 && world !== "durazno" && world !== "eclipse") return;
    if (kind === "snare" && intensity < 0.28 && world !== "durazno" && world !== "eclipse") return;
    notes.push({
      tick,
      durationTicks: kind === "kick" ? 3 : 1,
      midi: kind === "kick" ? 36 : kind === "snare" ? 48 : kind === "click" ? 94 : 80,
      velocity: (step >= 2 ? 0.96 : 0.72) * (kind === "hat" ? Math.max(0.44, amount * mode.pulse) : amount),
      voice: voiceFor(kind),
      priority: kind === "kick" ? 6 : kind === "snare" ? 4 : 2,
      layer: "percussion",
    });
  };

  for (let tick = 0; tick < TICKS_PER_BAR; tick++) {
    place("kick", tick, at(pattern.kick, tick));
    place("snare", tick, at(pattern.snare, tick));
    if (intensity >= 0.18 || world === "durazno" || world === "eclipse") {
      place("hat", tick, at(pattern.hat, tick));
    }
    place("click", tick, at(pattern.click, tick));
  }

  if (intensity >= 0.72 && world !== "glaciar" && section !== "INTRO") {
    for (const tick of [2, 6, 10, 14]) {
      if (!notes.some((n) => n.voice === "hat" && n.tick === tick)) {
        notes.push({
          tick,
          durationTicks: 1,
          midi: 80,
          velocity: 0.4 + intensity * 0.2,
          voice: "hat",
          priority: 2,
          layer: "percussion",
        });
      }
    }
  }

  const allowFill = composer ? isFill : isFill || (section === "BUILD" && rng.chance(0.62)) || (section === "PEAK" && rng.chance(0.45));
  if (allowFill) {
    for (let tick = 12; tick < 16; tick++) {
      notes.push({
        tick,
        durationTicks: 1,
        midi: tick % 2 === 0 ? 48 : 94,
        velocity: 0.66 + (tick - 12) * 0.06,
        voice: tick % 2 === 0 ? "snare" : "click",
        priority: tick % 2 === 0 ? 4 : 2,
        layer: "percussion",
      });
    }
  }
}

function addMelody(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  ctx: ComposeContext,
  section: SectionId,
  density: number,
  rng: ReturnType<typeof createPrng>,
  policy: TensionPolicy,
  polish: boolean,
  plan: PhraseBarPlan | null,
  localBar: number,
) {
  if (section === "TRANSITION") return;
  if (plan && !plan.melodyActive) return;
  const phraseBar = ctx.barIndex % 4;
  const signature = session.motifs[0]!;
  const secondary = session.motifs[1] ?? signature;
  const useSecondary = section === "B" || (section === "A_VARIATION" && phraseBar >= 2);
  let motif = useSecondary ? secondary : signature;

  if (!plan) {
    if (section === "INTRO") {
      const cut = phraseBar === 0 ? 3 : signature.contour.length;
      motif = {
        ...signature,
        contour: signature.contour.slice(0, cut),
        rhythm: signature.rhythm.slice(0, cut),
        rests: signature.rests.slice(0, cut),
        accents: signature.accents.slice(0, cut),
      };
    } else if (section === "RECOVERY" && phraseBar % 2 === 1) {
      return;
    } else if (ctx.intensity < 0.14 && phraseBar === 3) {
      return;
    } else if (rng.chance(session.theme.restBias * 0.22 * (1.05 - density))) {
      return;
    }
  } else if (section === "INTRO") {
    const cut = plan.role === "statement" ? Math.min(3, signature.contour.length) : signature.contour.length;
    motif = {
      ...signature,
      contour: signature.contour.slice(0, cut),
      rhythm: signature.rhythm.slice(0, cut),
      rests: signature.rests.slice(0, cut),
      accents: signature.accents.slice(0, cut),
    };
  }

  const kind = plan
    ? variationForStage(plan.motifStage, localBar)
    : section === "A" && phraseBar === 0
      ? "prime"
      : pickVariation(ctx.barIndex, rng);
  const realizedMotif = kind === "prime" ? motif : plan ? varyMotifComposed(motif, kind) : varyMotif(motif, kind, rng);
  const grammar = grammarFor(session.themeId === "procedural" ? session.dna.progressionFamily : session.themeId);
  const register = plan
    ? grammar.registerZones.motif
    : shiftRegister(session.theme.melodyRegister, ctx.combo, ctx.barIndex, section);
  const voice: VoiceName =
    session.themeId === "glaciar" ? "bell" : session.themeId === "durazno" ? "pluck" : "lead";
  const simpleLead = plan?.tensionOwner === "pad";
  const realized = realizeMotif({
    motif: realizedMotif,
    tonicPc: session.tonicPc,
    scale: session.scale,
    chord: voicing,
    register,
    startTick: plan ? plan.melodyStartTick : phraseBar === 1 && section !== "INTRO" ? 2 : 0,
    voice,
    velocity: 0.86 + density * 0.14,
    policy: simpleLead ? "strict" : policy,
    polish,
  });
  for (const note of realized) {
    if (note.tick >= TICKS_PER_BAR) continue;
    notes.push({ ...note, priority: 8, layer: "melody" });
  }
}

function addCounter(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  ctx: ComposeContext,
  rng: ReturnType<typeof createPrng>,
  policy: TensionPolicy,
  polish: boolean,
  plan: PhraseBarPlan | null,
) {
  const grammar = grammarFor(session.themeId === "procedural" ? session.dna.progressionFamily : session.themeId);
  const sparse = Boolean(plan?.melodyActive);
  const motif = plan
    ? varyMotifComposed(session.motifs[0]!, plan.melodyDirection >= 0 ? "invert" : "fragment")
    : varyMotif(session.motifs[0]!, "response", rng);
  const register = plan
    ? grammar.registerZones.counter
    : shiftRegister([session.theme.melodyRegister[0] + 5, session.theme.melodyRegister[1] + 4], ctx.combo, ctx.barIndex, "PEAK");
  if (sparse) {
    const tone = nearestChordTone((voicing.midi[1] ?? voicing.rootMidi) + (plan?.melodyDirection === 1 ? -5 : 7), voicing);
    notes.push({
      tick: 8,
      durationTicks: 6,
      midi: clampMidi(Math.max(register[0], Math.min(register[1], tone))),
      velocity: 0.48,
      voice: "bell",
      pan: -0.28,
      priority: 3,
      layer: "counter",
    });
    return;
  }
  const realized = realizeMotif({
    motif,
    tonicPc: session.tonicPc,
    scale: session.scale,
    chord: voicing,
    register,
    startTick: 8,
    voice: "bell",
    velocity: 0.56,
    policy,
    polish,
  });
  notes.push(
    ...realized
      .filter((n) => n.tick < TICKS_PER_BAR)
      .map((n) => ({ ...n, velocity: n.velocity * 0.85, priority: 3, layer: "counter" as const })),
  );
}

function addArp(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  density: number,
  rng: ReturnType<typeof createPrng>,
  combo: number,
  section: SectionId,
  intensity: number,
  plan: PhraseBarPlan | null,
) {
  if (section === "RECOVERY" || section === "TRANSITION") return;
  if (plan && !plan.arpActive) return;
  if (section === "INTRO" && intensity < 0.35) return;
  const world = session.themeId;
  if (!plan) {
    if (world !== "lavanda" && world !== "eclipse" && intensity < 0.22) return;
    if (world !== "lavanda" && density < 0.32 && intensity < 0.38) return;
    if (world === "durazno" && intensity < 0.55 && section !== "BUILD" && section !== "PEAK") return;
  }
  const grammar = grammarFor(world === "procedural" ? session.dna.progressionFamily : world);
  const ticks = plan ? grammar.ostinatoTicks : session.theme.arpTicks;
  const zones = grammar.registerZones.ostinato;
  const tones = chordTonesMidi(voicing, plan ? zones : [session.theme.melodyRegister[0] - 5, session.theme.melodyRegister[1] - 4]);
  if (tones.length === 0) return;
  const dense = combo >= 8 || intensity > 0.58 || section === "PEAK" || section === "BUILD" || world === "lavanda";
  const used = dense ? ticks : ticks.filter((_, i) => i % 2 === 0 || ticks.length <= 4);
  let dir = 1;
  let idx = plan ? 0 : rng.nextInt(tones.length);
  const vel = 0.52 + density * 0.2 + (world === "lavanda" ? 0.08 : 0);
  for (const tick of used) {
    notes.push({
      tick,
      durationTicks: 2,
      midi: tones[idx] ?? tones[0]!,
      velocity: vel,
      voice: world === "glaciar" || world === "lavanda" ? "bell" : "pluck",
      pan: ((tick % 8) / 8 - 0.5) * 0.5,
      priority: 3,
      layer: "arp",
    });
    idx += dir;
    if (idx >= tones.length || idx < 0) {
      dir *= -1;
      idx = Math.max(0, Math.min(tones.length - 1, idx + dir));
    }
  }
}

function addPickupEcho(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  contour: number[],
  _rng: ReturnType<typeof createPrng>,
  policy: TensionPolicy,
  polish: boolean,
) {
  const fragment = contour.slice(-4);
  let tick = 8;
  for (const midi of fragment) {
    let fitted = midi;
    if (polish) {
      fitted = isBeatTick(tick)
        ? nearestChordTone(fitted, voicing)
        : chooseResolvedPickup(fitted, voicing, session.tonicPc, session.scale, policy);
    } else if (!isChordTone(fitted, voicing)) {
      fitted = nearestScaleMidi(fitted, session.tonicPc, session.scale);
    }
    notes.push({
      tick,
      durationTicks: 2,
      midi: clampMidi(fitted),
      velocity: 0.55,
      voice: "bell",
      priority: 4,
      layer: "gameplay",
    });
    tick += 2;
    if (tick >= 16) break;
  }
}

function shiftRegister(
  register: [number, number],
  combo: number,
  barIndex: number,
  section: SectionId,
): [number, number] {
  const comboLift = Math.min(7, Math.floor(combo / 10));
  const cycleLift = barIndex % 32 >= 24 ? 3 : 0;
  const sectionLift = section === "B" ? 3 : section === "PEAK" ? 5 : section === "RECOVERY" ? -2 : 0;
  return [register[0] + comboLift + cycleLift + sectionLift, register[1] + comboLift + cycleLift + sectionLift];
}

export function choosePickupMidi(options: {
  voicing: ChordVoicing;
  tonicPc: number;
  scale: import("../core/types.ts").ScaleName;
  combo: number;
  strongBeat: boolean;
  rng: ReturnType<typeof createPrng>;
  policy?: TensionPolicy;
}): number {
  const { voicing, combo, strongBeat, rng } = options;
  const policy = options.policy ?? "strict";
  const register: [number, number] = combo >= 20 ? [79, 96] : combo >= 8 ? [72, 88] : [67, 84];
  const chordPool = chordTonesMidi(voicing, register);
  const scaleExtra = nearestScaleMidi(voicing.rootMidi + 2, options.tonicPc, options.scale) + 12;
  const pool =
    strongBeat || combo < 4
      ? chordPool
      : [...chordPool, ...(policy === "strict" && isHarshAgainstChord(scaleExtra, voicing) ? [] : [scaleExtra])];
  const safe = pool.filter((midi) => !isHarshAgainstChord(midi, voicing) || policy !== "strict");
  const chosen = safe.length ? rng.pick(safe) : pool.length ? rng.pick(pool) : voicing.rootMidi + 12;
  return clampMidi(chooseResolvedPickup(chosen, voicing, options.tonicPc, options.scale, policy));
}

export function choosePickupHarmony(
  primary: number,
  voicing: ChordVoicing,
  tonicPc: number,
  scale: import("../core/types.ts").ScaleName,
  policy: TensionPolicy,
  rng: ReturnType<typeof createPrng>,
): number | null {
  const register: [number, number] = [Math.max(67, primary - 5), Math.min(98, primary + 12)];
  const candidates = chordTonesMidi(voicing, register).filter((m) => m !== primary);
  const ok = candidates.filter((midi) => consonantPickupInterval(primary, midi, policy));
  if (ok.length) return clampMidi(rng.pick(ok));
  const fifth = nearestMidi((voicing.pitchClasses[2] ?? voicing.rootMidi) % 12, primary + 7);
  if (consonantPickupInterval(primary, fifth, policy)) return clampMidi(fifth);
  return null;
}
