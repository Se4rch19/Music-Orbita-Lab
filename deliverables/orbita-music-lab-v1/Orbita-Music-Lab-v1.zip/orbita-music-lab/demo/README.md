# Listening demo

The React lab UI lives here as a reference. In the Grok preview it is already running.

To integrate, you only need `../src` (`OrbitaMusicEngine`). Do not import this demo into Órbita.
