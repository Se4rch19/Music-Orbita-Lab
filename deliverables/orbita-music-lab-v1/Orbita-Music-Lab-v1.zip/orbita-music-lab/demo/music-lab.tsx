import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Download,
  Pause,
  Play,
  Square,
  Volume2,
  VolumeX,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { OrbitVisualizer } from "@/components/lab/orbit-visualizer";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";
import {
  OrbitaMusicEngine,
  BIOMES,
  MOODS,
  type EngineDiagnostics,
  type GameMode,
  type OrbitaTheme,
  type PlanetBiome,
  type PlanetMood,
  type PlanetMusicProfile,
} from "@/orbita-music-lab";

const WORLDS: { id: OrbitaTheme; label: string; hint: string }[] = [
  { id: "menta", label: "Menta", hint: "Discovery" },
  { id: "durazno", label: "Durazno", hint: "Playful" },
  { id: "lavanda", label: "Lavanda", hint: "Dreamlike" },
  { id: "glaciar", label: "Glaciar", hint: "Crystal" },
  { id: "eclipse", label: "Eclipse", hint: "Final" },
  { id: "procedural", label: "Planet", hint: "Generated" },
];

const MODES: { id: GameMode; label: string }[] = [
  { id: "expedition", label: "Expedition" },
  { id: "calm", label: "Calm" },
  { id: "daily", label: "Daily" },
  { id: "infinite", label: "Infinite" },
  { id: "anomaly", label: "Anomaly" },
];

const WORLD_CLASS: Record<string, string> = {
  menta: "data-[on=true]:border-world-menta",
  durazno: "data-[on=true]:border-world-durazno",
  lavanda: "data-[on=true]:border-world-lavanda",
  glaciar: "data-[on=true]:border-world-glaciar",
  eclipse: "data-[on=true]:border-world-eclipse",
  procedural: "data-[on=true]:border-accent",
};

const idleDiagnostics: EngineDiagnostics = {
  activeVoices: 0,
  scheduledEvents: 0,
  bpm: 0,
  currentBar: 0,
  currentBeat: 0,
  beatsPerBar: 4,
  subdivision: 4,
  section: "idle",
  theme: "idle",
  intensity: 0.35,
  combo: 0,
  mode: "expedition",
  seed: "",
  scale: "none",
  keyName: "-",
  running: false,
  paused: false,
  suspended: false,
};

export function MusicLab() {
  const engineRef = useRef<OrbitaMusicEngine | null>(null);
  const [ready, setReady] = useState(false);
  const [theme, setTheme] = useState<OrbitaTheme>("menta");
  const [seed, setSeed] = useState("MENTA-2026-001");
  const [intensity, setIntensity] = useState(35);
  const [combo, setCombo] = useState(0);
  const [mode, setMode] = useState<GameMode>("expedition");
  const [musicVol, setMusicVol] = useState(85);
  const [sfxVol, setSfxVol] = useState(90);
  const [muted, setMuted] = useState({ music: false, sfx: false });
  const [diag, setDiag] = useState<EngineDiagnostics>(idleDiagnostics);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [status, setStatus] = useState("Tap play to open the lab.");
  const [biome, setBiome] = useState<PlanetBiome>("crystal");
  const [mood, setMood] = useState<PlanetMood>("mysterious");
  const [danger, setDanger] = useState(25);
  const [luminosity, setLuminosity] = useState(60);
  const [anomaly, setAnomaly] = useState(30);
  const [error, setError] = useState<string | null>(null);

  const profile = useMemo<PlanetMusicProfile>(
    () => ({
      seed,
      biome,
      mood,
      intensity: intensity / 100,
      temperature: biome === "lava" ? 0.9 : biome === "glacial" ? 0.1 : 0.5,
      luminosity: luminosity / 100,
      danger: danger / 100,
      anomaly: anomaly / 100,
    }),
    [seed, biome, mood, intensity, luminosity, danger, anomaly],
  );

  useEffect(() => {
    const engine = new OrbitaMusicEngine();
    engineRef.current = engine;
    const id = window.setInterval(() => {
      setDiag(engine.getDiagnostics());
    }, 120);
    return () => {
      window.clearInterval(id);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const ensure = useCallback(async () => {
    const engine = engineRef.current;
    if (!engine) return null;
    await engine.initialize();
    await engine.resumeAudioContext();
    setAnalyser(engine.getAnalyser());
    setReady(true);
    return engine;
  }, []);

  const start = useCallback(async () => {
    try {
      setError(null);
      const engine = await ensure();
      if (!engine) return;
      engine.setIntensity(intensity / 100);
      engine.setCombo(combo);
      engine.setGameMode(mode);
      engine.setMusicVolume(musicVol / 100);
      engine.setSfxVolume(sfxVol / 100);
      if (theme === "procedural") {
        engine.startTheme("procedural", { seed, profile });
      } else {
        engine.startTheme(theme, { seed });
      }
      setStatus("Playing");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Audio failed to start");
    }
  }, [combo, ensure, intensity, mode, musicVol, profile, seed, sfxVol, theme]);

  const onWorld = async (id: OrbitaTheme) => {
    setTheme(id);
    const engine = engineRef.current;
    if (!engine || !ready) return;
    if (id === "procedural") engine.transitionToPlanet(profile);
    else engine.transitionToTheme(id, { seed });
  };

  useEffect(() => {
    engineRef.current?.setIntensity(intensity / 100);
  }, [intensity]);
  useEffect(() => {
    engineRef.current?.setCombo(combo);
  }, [combo]);
  useEffect(() => {
    engineRef.current?.setGameMode(mode);
  }, [mode]);
  useEffect(() => {
    engineRef.current?.setMusicVolume(musicVol / 100);
  }, [musicVol]);
  useEffect(() => {
    engineRef.current?.setSfxVolume(sfxVol / 100);
  }, [sfxVol]);

  const exportJson = () => {
    const plan = engineRef.current?.exportCompositionPlan();
    if (!plan) return;
    const blob = new Blob([JSON.stringify(plan, null, 2)], { type: "application/json" });
    downloadBlob(blob, `orbita-${theme}-${seed}.json`);
  };

  const exportWav = async (seconds: number) => {
    const engine = engineRef.current;
    if (!engine || !ready) return;
    setStatus(`Rendering ${seconds}s…`);
    try {
      const wav = await engine.renderOffline(seconds);
      downloadBlob(new Blob([new Uint8Array(wav)], { type: "audio/wav" }), `orbita-${theme}-${seconds}s.wav`);
      setStatus("Playing");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Render failed");
      setStatus("Playing");
    }
  };

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-6 pb-16 sm:px-6 lg:px-8">
        <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-medium tracking-[0.22em] text-muted uppercase">Órbita</p>
            <h1 className="mt-1 font-display text-4xl font-medium tracking-tight text-fg sm:text-5xl">
              Music Lab
            </h1>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
              Original procedural soundtrack engine. Offline, seeded, and reactive to the traveler.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="primary" onClick={() => void start()} className="min-w-24">
              <Play className="size-4 translate-x-px" />
              Play
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                engineRef.current?.pause();
                setStatus("Paused");
              }}
              aria-label="Pause"
            >
              <Pause className="size-4" />
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                engineRef.current?.stop();
                setStatus("Stopped");
                setDiag(engineRef.current?.getDiagnostics() ?? idleDiagnostics);
              }}
              aria-label="Stop"
            >
              <Square className="size-3.5" />
            </Button>
            <Button
              variant="ghost"
              onClick={() => {
                const next = { ...muted, music: !muted.music };
                setMuted(next);
                engineRef.current?.setMuted(next.music, next.sfx);
              }}
              aria-label="Mute music"
            >
              {muted.music ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            </Button>
          </div>
        </header>

        {error ? (
          <p className="rounded-md bg-surface px-3 py-2 text-sm text-danger shadow-border">{error}</p>
        ) : null}

        <section className="overflow-hidden rounded-xl bg-bg-elevated shadow-border">
          <div className="relative h-56 sm:h-72 lg:h-80">
            <OrbitVisualizer analyser={analyser} diagnostics={diag} theme={diag.theme} />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
              <div>
                <p className="font-display text-xl text-fg">{labelFor(theme)}</p>
                <p className="text-xs text-muted">
                  {diag.keyName} {diag.scale} · {status}
                </p>
              </div>
            </div>
          </div>
          <dl className="grid grid-cols-3 gap-px bg-border sm:grid-cols-6">
            <Stat label="BPM" value={diag.bpm ? diag.bpm.toFixed(0) : "—"} />
            <Stat label="Bar" value={String(diag.currentBar)} />
            <Stat label="Beat" value={diag.currentBeat.toFixed(2)} />
            <Stat label="Section" value={diag.section} />
            <Stat label="Voices" value={String(diag.activeVoices)} />
            <Stat label="Theme" value={String(diag.theme)} />
          </dl>
        </section>

        <section>
          <Label>World</Label>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {WORLDS.map((world) => (
              <button
                key={world.id}
                type="button"
                data-on={theme === world.id}
                onClick={() => void onWorld(world.id)}
                className={cn(
                  "min-h-11 rounded-md bg-surface px-3 py-2 text-left shadow-border transition-[background-color,border-color] duration-150",
                  "border border-transparent hover:bg-surface-2",
                  WORLD_CLASS[world.id],
                  theme === world.id && "border-current bg-surface-2",
                )}
              >
                <span className="block text-sm font-medium">{world.label}</span>
                <span className="block text-xs text-muted">{world.hint}</span>
              </button>
            ))}
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-lg bg-surface p-4 shadow-border sm:p-5">
            <Label>Intensity</Label>
            <SliderRow
              value={intensity}
              onChange={setIntensity}
              display={`${intensity}%`}
            />
            <div className="mt-4">
              <Label>Combo</Label>
              <SliderRow value={combo} max={40} onChange={setCombo} display={String(combo)} />
            </div>
            <div className="mt-4">
              <Label>Mode</Label>
              <div className="mt-2 flex flex-wrap gap-2">
                {MODES.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setMode(item.id)}
                    className={cn(
                      "min-h-11 rounded-sm px-3 text-sm shadow-border",
                      mode === item.id ? "bg-accent text-accent-fg" : "bg-surface-2 text-fg",
                    )}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <div>
                <Label>Music</Label>
                <SliderRow value={musicVol} onChange={setMusicVol} display={`${musicVol}%`} />
              </div>
              <div>
                <Label>Events</Label>
                <SliderRow value={sfxVol} onChange={setSfxVol} display={`${sfxVol}%`} />
              </div>
            </div>
          </section>

          <section className="rounded-lg bg-surface p-4 shadow-border sm:p-5">
            <Label>Events</Label>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
              <EventBtn label="Collect light" onClick={() => engineRef.current?.triggerLightPickup()} />
              <EventBtn label="Orbit in" onClick={() => engineRef.current?.triggerOrbitIn()} />
              <EventBtn label="Orbit out" onClick={() => engineRef.current?.triggerOrbitOut()} />
              <EventBtn label="Shield hit" onClick={() => engineRef.current?.triggerShieldHit()} />
              <EventBtn label="Damage" onClick={() => engineRef.current?.triggerDamage()} />
              <EventBtn label="Run end" onClick={() => engineRef.current?.triggerRunEnd()} />
            </div>
            <div className="mt-5">
              <Label htmlFor="seed">Seed</Label>
              <input
                id="seed"
                value={seed}
                onChange={(e) => setSeed(e.target.value)}
                className="mt-2 h-11 w-full rounded-sm bg-bg px-3 font-mono text-sm text-fg shadow-border outline-none focus:ring-2 focus:ring-accent/40"
              />
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button onClick={exportJson} size="sm">
                <Download className="size-3.5" />
                Plan JSON
              </Button>
              <Button onClick={() => void exportWav(30)} size="sm">
                Render 30s
              </Button>
              <Button onClick={() => void exportWav(60)} size="sm">
                Render 60s
              </Button>
            </div>
          </section>
        </div>

        {theme === "procedural" ? (
          <section className="rounded-lg bg-surface p-4 shadow-border sm:p-5">
            <Label>Procedural planet</Label>
            <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Biome">
                <select
                  value={biome}
                  onChange={(e) => setBiome(e.target.value as PlanetBiome)}
                  className="h-11 w-full rounded-sm bg-bg px-3 text-sm shadow-border"
                >
                  {BIOMES.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Mood">
                <select
                  value={mood}
                  onChange={(e) => setMood(e.target.value as PlanetMood)}
                  className="h-11 w-full rounded-sm bg-bg px-3 text-sm shadow-border"
                >
                  {MOODS.map((item) => (
                    <option key={item} value={item}>
                      {optionLabel(item)}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label={`Danger ${danger}%`}>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={danger}
                  onChange={(e) => setDanger(Number(e.target.value))}
                  className="w-full accent-accent"
                />
              </Field>
              <Field label={`Luminosity ${luminosity}%`}>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={luminosity}
                  onChange={(e) => setLuminosity(Number(e.target.value))}
                  className="w-full accent-accent"
                />
              </Field>
              <Field label={`Anomaly ${anomaly}%`}>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={anomaly}
                  onChange={(e) => setAnomaly(Number(e.target.value))}
                  className="w-full accent-accent"
                />
              </Field>
            </div>
          </section>
        ) : null}

        <p className="text-center text-xs text-subtle">
          All music is generated from original grammars. No samples, no streaming, no network.
        </p>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-bg-elevated px-3 py-3">
      <dt className="text-[10px] tracking-[0.16em] text-muted uppercase">{label}</dt>
      <dd className="mt-1 font-mono text-sm tabular text-fg">{value}</dd>
    </div>
  );
}

function Label({ children, htmlFor }: { children: ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="text-[11px] font-medium tracking-[0.16em] text-muted uppercase">
      {children}
    </label>
  );
}

function SliderRow({
  value,
  onChange,
  display,
  max = 100,
}: {
  value: number;
  onChange: (value: number) => void;
  display: string;
  max?: number;
}) {
  return (
    <div className="mt-2 flex items-center gap-3">
      <input
        type="range"
        min={0}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-11 w-full accent-accent"
      />
      <span className="w-12 text-right font-mono text-sm tabular text-fg">{display}</span>
    </div>
  );
}

function EventBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <Button variant="secondary" size="sm" className="h-11 w-full" onClick={onClick}>
      {label}
    </Button>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block text-xs text-muted">
      <span className="mb-2 block tracking-[0.14em] uppercase">{label}</span>
      {children}
    </label>
  );
}

function labelFor(id: OrbitaTheme) {
  return WORLDS.find((w) => w.id === id)?.label ?? id;
}

function optionLabel(value: string) {
  return value.slice(0, 1).toUpperCase() + value.slice(1);
}

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}
