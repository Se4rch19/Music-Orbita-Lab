export { OrbitaMusicEngine } from "./engine/OrbitaMusicEngine.ts";
export { createPrng, hashSeed } from "./core/prng.ts";
export { createSession, exportPlan, sectionAtBar } from "./composition/session.ts";
export { composeBar, choosePickupMidi } from "./composition/compose-bar.ts";
export { mapPlanetProfile, nearestCuratedTheme } from "./composition/planet-mapper.ts";
export { getCuratedTheme, CURATED_THEMES } from "./themes/catalog.ts";
export { validateBar, validateNote, validatePickup } from "./core/validation.ts";
export { midiToFreq, pcName, clampMidi } from "./core/pitch.ts";
export { chordKey, voiceChord, formatChord, chordPitchClasses } from "./theory/chords.ts";
export { generateProgression } from "./theory/harmony.ts";
export { realizeMotif, varyMotif } from "./theory/motifs.ts";
export { isInScale, scalePitchClasses, SCALE_INTERVALS } from "./theory/scales.ts";
export { encodeWav } from "./engine/wav.ts";

export type { OrbitaThemeId, OrbitaThemeId as OrbitaTheme } from "./core/types.ts";
export type {
  PlanetMusicProfile,
  PlanetBiome,
  PlanetMood,
  GameMode,
  EngineDiagnostics,
  EngineConfig,
  CompositionPlanJson,
  StartThemeOptions,
  LightPickupOptions,
  BarScore,
  WorldThemeDefinition,
  SectionId,
  ScaleName,
} from "./core/types.ts";
export { BIOMES, MOODS, THEME_IDS, GAME_MODES } from "./core/types.ts";
