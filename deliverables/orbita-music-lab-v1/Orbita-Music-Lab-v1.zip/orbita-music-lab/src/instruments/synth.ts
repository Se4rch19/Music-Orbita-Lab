import { midiToFreq } from "../core/pitch.ts";
import type { InstrumentTimbre, VoiceName } from "../core/types.ts";

export type PlayVoiceOpts = {
  ctx: BaseAudioContext;
  dest: AudioNode;
  time: number;
  midi: number;
  duration: number;
  velocity: number;
  pan?: number;
  timbre: InstrumentTimbre;
  intensity: number;
};

export function playVoice(name: VoiceName, opts: PlayVoiceOpts): AudioNode[] {
  switch (name) {
    case "pad":
      return playPad(opts);
    case "pluck":
    case "arp":
      return playPluck(opts);
    case "bass":
      return playBass(opts);
    case "lead":
      return playLead(opts);
    case "bell":
      return playBell(opts);
    case "kick":
      return playKick(opts);
    case "snare":
      return playSnare(opts);
    case "hat":
      return playHat(opts);
    case "click":
      return playClick(opts);
    case "noise":
      return playNoise(opts);
    case "pickup":
      return playPickup(opts);
    case "event":
      return playEvent(opts);
    default:
      return playPluck(opts);
  }
}

function playPad(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, duration, velocity, timbre, intensity, pan } = opts;
  const freq = midiToFreq(midi);
  const cutoff = timbre.padCutoff * (0.7 + intensity * 0.6);
  const mix = ctx.createGain();
  mix.gain.setValueAtTime(0.0001, time);
  mix.gain.exponentialRampToValueAtTime(0.07 * velocity, time + 0.4);
  mix.gain.setTargetAtTime(0.06 * velocity, time + 0.45, 0.3);
  mix.gain.setTargetAtTime(0.0001, time + Math.max(0.6, duration - 0.7), 0.35);
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = cutoff;
  filter.Q.value = 0.5;
  const output = panNode(ctx, dest, pan);
  mix.connect(filter);
  filter.connect(output);
  const nodes: AudioNode[] = [mix, filter, output];
  for (const detune of [-timbre.padDetune, 0, timbre.padDetune]) {
    const osc = ctx.createOscillator();
    osc.type = "triangle";
    osc.frequency.value = freq;
    osc.detune.value = detune;
    osc.connect(mix);
    osc.start(time);
    osc.stop(time + duration + 0.15);
    nodes.push(osc);
  }
  return nodes;
}

function playPluck(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, duration, velocity, timbre, intensity, pan } = opts;
  const osc = ctx.createOscillator();
  osc.type = "triangle";
  osc.frequency.value = midiToFreq(midi);
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  const startCut = timbre.pluckCutoff * (0.7 + intensity * 0.5);
  filter.frequency.setValueAtTime(startCut, time);
  filter.frequency.exponentialRampToValueAtTime(Math.max(180, startCut * 0.18), time + Math.min(0.4, duration));
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.16 * velocity, time + 0.008);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.12, duration));
  const output = panNode(ctx, dest, pan);
  osc.connect(filter);
  filter.connect(gain);
  gain.connect(output);
  osc.start(time);
  osc.stop(time + duration + 0.05);
  return [osc, filter, gain, output];
}

function playBass(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, duration, velocity, timbre, intensity } = opts;
  const freq = midiToFreq(Math.max(36, midi));
  const sine = ctx.createOscillator();
  sine.type = "sine";
  sine.frequency.value = freq;
  const tri = ctx.createOscillator();
  tri.type = "triangle";
  tri.frequency.value = freq;
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = timbre.bassCutoff * (0.85 + intensity * 0.4);
  filter.Q.value = 0.8;
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.22 * velocity, time + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.16, duration));
  sine.connect(filter);
  tri.connect(filter);
  filter.connect(gain);
  gain.connect(dest);
  sine.start(time);
  tri.start(time);
  sine.stop(time + duration + 0.05);
  tri.stop(time + duration + 0.05);
  return [sine, tri, filter, gain];
}

function playLead(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, duration, velocity, timbre, intensity, pan } = opts;
  const osc = ctx.createOscillator();
  osc.type = "sawtooth";
  osc.frequency.value = midiToFreq(midi);
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = timbre.leadCutoff * (0.6 + intensity * 0.7);
  filter.Q.value = 1.1;
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.09 * velocity, time + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.18, duration));
  const output = panNode(ctx, dest, pan);
  osc.connect(filter);
  filter.connect(gain);
  gain.connect(output);
  osc.start(time);
  osc.stop(time + duration + 0.05);
  return [osc, filter, gain, output];
}

function playBell(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, duration, velocity, timbre, pan } = opts;
  const freq = midiToFreq(midi);
  const ratios = [1, 2.05 + timbre.bellInharmonic, 3.1 + timbre.bellInharmonic * 1.4];
  const mix = ctx.createGain();
  mix.gain.setValueAtTime(0.0001, time);
  mix.gain.exponentialRampToValueAtTime(0.1 * velocity, time + 0.006);
  mix.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.3, duration * 1.4));
  const output = panNode(ctx, dest, pan);
  mix.connect(output);
  const oscs: AudioNode[] = [];
  ratios.forEach((ratio, i) => {
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq * ratio;
    const partial = ctx.createGain();
    partial.gain.value = i === 0 ? 1 : 0.28 / (i + 1);
    osc.connect(partial);
    partial.connect(mix);
    osc.start(time);
    osc.stop(time + duration + 0.2);
    oscs.push(osc, partial);
  });
  return [...oscs, mix, output];
}

function playKick(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, velocity } = opts;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(148, time);
  osc.frequency.exponentialRampToValueAtTime(46, time + 0.07);
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.55 * velocity, time + 0.004);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.22);
  osc.connect(gain);
  gain.connect(dest);
  osc.start(time);
  osc.stop(time + 0.28);
  const click = ctx.createOscillator();
  click.type = "square";
  click.frequency.value = 420;
  const clickGain = ctx.createGain();
  clickGain.gain.setValueAtTime(0.08 * velocity, time);
  clickGain.gain.exponentialRampToValueAtTime(0.0001, time + 0.02);
  click.connect(clickGain);
  clickGain.connect(dest);
  click.start(time);
  click.stop(time + 0.03);
  return [osc, gain, click, clickGain];
}

function playSnare(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, velocity } = opts;
  const noise = noiseSource(ctx, time, 0.18);
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 1200;
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 1800;
  bp.Q.value = 0.8;
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.28 * velocity, time + 0.004);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.16);
  noise.connect(hp);
  hp.connect(bp);
  bp.connect(gain);
  gain.connect(dest);
  const body = ctx.createOscillator();
  body.type = "triangle";
  body.frequency.setValueAtTime(190, time);
  body.frequency.exponentialRampToValueAtTime(110, time + 0.08);
  const bodyGain = ctx.createGain();
  bodyGain.gain.setValueAtTime(0.12 * velocity, time);
  bodyGain.gain.exponentialRampToValueAtTime(0.0001, time + 0.1);
  body.connect(bodyGain);
  bodyGain.connect(dest);
  body.start(time);
  body.stop(time + 0.12);
  return [noise, hp, bp, gain, body, bodyGain];
}

function playHat(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, velocity, midi } = opts;
  const noise = noiseSource(ctx, time, 0.08);
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = midi > 82 ? 9000 : 7000;
  const gain = ctx.createGain();
  const dur = midi > 82 ? 0.12 : 0.035;
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.1 * velocity, time + 0.002);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + dur);
  noise.connect(hp);
  hp.connect(gain);
  gain.connect(dest);
  return [noise, hp, gain];
}

function playClick(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, velocity, pan } = opts;
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.value = midiToFreq(Math.max(72, midi));
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.12 * velocity, time + 0.002);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.07);
  const output = panNode(ctx, dest, pan ?? 0.2);
  osc.connect(gain);
  gain.connect(output);
  osc.start(time);
  osc.stop(time + 0.09);
  return [osc, gain, output];
}

function playNoise(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, duration, velocity, timbre } = opts;
  const noise = noiseSource(ctx, time, duration);
  const filter = ctx.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.value = 1800;
  filter.Q.value = 0.4;
  const gain = ctx.createGain();
  gain.gain.value = 0.04 * velocity * timbre.noiseAmount;
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(dest);
  return [noise, filter, gain];
}

function playPickup(opts: PlayVoiceOpts): AudioNode[] {
  const { ctx, dest, time, midi, velocity, pan } = opts;
  const freq = midiToFreq(midi);
  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.value = freq;
  const osc2 = ctx.createOscillator();
  osc2.type = "triangle";
  osc2.frequency.value = freq * 2;
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(4200, time);
  filter.frequency.exponentialRampToValueAtTime(1400, time + 0.25);
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.0001, time);
  gain.gain.exponentialRampToValueAtTime(0.22 * velocity, time + 0.005);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.38);
  const output = panNode(ctx, dest, pan ?? 0);
  osc.connect(filter);
  osc2.connect(filter);
  filter.connect(gain);
  gain.connect(output);
  osc.start(time);
  osc2.start(time);
  osc.stop(time + 0.42);
  osc2.stop(time + 0.42);
  const noise = noiseSource(ctx, time, 0.04);
  const hp = ctx.createBiquadFilter();
  hp.type = "highpass";
  hp.frequency.value = 4000;
  const nGain = ctx.createGain();
  nGain.gain.setValueAtTime(0.1 * velocity, time);
  nGain.gain.exponentialRampToValueAtTime(0.0001, time + 0.03);
  noise.connect(hp);
  hp.connect(nGain);
  nGain.connect(output);
  return [osc, osc2, filter, gain, output, noise, hp, nGain];
}

function playEvent(opts: PlayVoiceOpts): AudioNode[] {
  return playClick(opts);
}

const noiseCache = new WeakMap<BaseAudioContext, AudioBuffer>();

function noiseSource(ctx: BaseAudioContext, time: number, duration: number): AudioBufferSourceNode {
  let buffer = noiseCache.get(ctx);
  if (!buffer) {
    buffer = ctx.createBuffer(1, Math.max(1, Math.floor(ctx.sampleRate * 0.4)), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    noiseCache.set(ctx, buffer);
  }
  const src = ctx.createBufferSource();
  src.buffer = buffer;
  src.loop = true;
  src.start(time);
  src.stop(time + duration + 0.02);
  return src;
}

function panNode(ctx: BaseAudioContext, dest: AudioNode, pan?: number): AudioNode {
  if (pan === undefined || Math.abs(pan) < 0.02) {
    const g = ctx.createGain();
    g.connect(dest);
    return g;
  }
  const panner = ctx.createStereoPanner();
  panner.pan.value = Math.max(-0.7, Math.min(0.7, pan));
  panner.connect(dest);
  return panner;
}
