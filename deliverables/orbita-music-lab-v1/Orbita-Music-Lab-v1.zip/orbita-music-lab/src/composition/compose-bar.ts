import { createPrng } from "../core/prng.ts";
import { clamp01, clampMidi, nearestMidi } from "../core/pitch.ts";
import type {
  BarScore,
  ChordVoicing,
  GameMode,
  PercHitKind,
  ScoreNote,
  SectionId,
  VoiceName,
} from "../core/types.ts";
import { TICKS_PER_BAR } from "../core/types.ts";
import { chordTonesMidi, isChordTone } from "../theory/chords.ts";
import { pickVariation, realizeMotif, varyMotif } from "../theory/motifs.ts";
import { nearestScaleMidi } from "../theory/scales.ts";
import { chordAtBar, modeModifiers, sectionAtBar, type SessionIdentity } from "./session.ts";

export type ComposeContext = {
  session: SessionIdentity;
  barIndex: number;
  intensity: number;
  combo: number;
  mode: GameMode;
  previousVoicing?: ChordVoicing;
  pickupContour?: number[];
  forceSection?: SectionId;
};

const SECTION_BASE: Record<SectionId, number> = {
  INTRO: 0.18,
  A: 0.38,
  A_VARIATION: 0.46,
  B: 0.5,
  BUILD: 0.72,
  PEAK: 0.9,
  RECOVERY: 0.32,
  TRANSITION: 0.2,
};

export function composeBar(ctx: ComposeContext): BarScore {
  const { session } = ctx;
  const sectionInfo = ctx.forceSection
    ? { id: ctx.forceSection, localBar: ctx.barIndex }
    : sectionAtBar(session, ctx.barIndex);
  const section = sectionInfo.id;
  const voicing = chordAtBar(session, section, sectionInfo.localBar, ctx.previousVoicing?.midi);
  const rng = createPrng(`${session.variationSeed}::bar:${ctx.barIndex}::${section}`);
  const mode = modeModifiers(ctx.mode);
  const energy = clamp01(SECTION_BASE[section] * 0.65 + ctx.intensity * 0.55);
  const density = clamp01(energy * mode.density);
  const percAmt = clamp01(energy * mode.percussion * (session.theme.densityRange[0] + density * 0.8));
  const notes: ScoreNote[] = [];

  const isFill = sectionInfo.localBar === 7 && energy > 0.45 && rng.chance(0.55 + ctx.intensity * 0.3);

  const chordChanged =
    !ctx.previousVoicing ||
    ctx.previousVoicing.pitchClasses.join(",") !== voicing.pitchClasses.join(",");
  if (chordChanged || ctx.barIndex % 2 === 0) {
    addPad(notes, voicing, density, mode.space, chordChanged);
  }
  addBass(notes, voicing, session, density, rng, section, mode.pulse);
  addPercussion(notes, session, percAmt, rng, isFill, mode, ctx.intensity);
  addMelody(notes, voicing, session, ctx, section, density, rng);
  addArp(notes, voicing, session, density, rng, ctx.combo, section);
  if (ctx.pickupContour && ctx.pickupContour.length >= 3 && rng.chance(0.22 + Math.min(0.3, ctx.combo / 40))) {
    addPickupEcho(notes, voicing, session, ctx.pickupContour, rng);
  }

  return {
    barIndex: ctx.barIndex,
    section,
    chord: voicing,
    notes: notes.filter((n) => Number.isFinite(n.midi) && n.velocity > 0 && n.durationTicks > 0),
    isFill,
  };
}

function addPad(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  density: number,
  space: number,
  chordChanged: boolean,
) {
  const vel = 0.24 + density * 0.16;
  const hold = chordChanged ? (space > 1.1 ? 28 : 20) : 18;
  const tones = voicing.midi.slice(0, 2);
  for (let i = 0; i < tones.length; i++) {
    const midi = tones[i]!;
    notes.push({
      tick: 0,
      durationTicks: hold,
      midi,
      velocity: vel * (i === 0 ? 0.9 : 0.75),
      voice: "pad",
      pan: i === 0 ? -0.18 : 0.18,
    });
  }
}

function addBass(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  density: number,
  rng: ReturnType<typeof createPrng>,
  section: SectionId,
  pulse: number,
) {
  if (section === "INTRO" && density < 0.25) {
    notes.push({
      tick: 0,
      durationTicks: 12,
      midi: voicing.bassMidi,
      velocity: 0.55,
      voice: "bass",
    });
    return;
  }
  const pattern = session.theme.bassPatterns[rng.nextInt(session.theme.bassPatterns.length)] ?? session.theme.bassPatterns[0]!;
  const steps = pattern.steps;
  const root = Math.max(36, voicing.bassMidi);
  const fifth = nearestMidi((voicing.pitchClasses[2] ?? (root + 7)) % 12, root + 7);
  const third = nearestMidi((voicing.pitchClasses[1] ?? root) % 12, root + 4);
  const octave = Math.min(50, root + 12);
  const approach = nearestScaleMidi(root - 2, session.tonicPc, session.scale);

  for (let tick = 0; tick < TICKS_PER_BAR; tick++) {
    const code = steps[tick % steps.length] ?? 0;
    if (code === 0) continue;
    if (density < 0.3 && tick % 8 !== 0) continue;
    if (pulse < 0.6 && tick % 4 !== 0 && code !== 1) continue;
    let midi = root;
    if (code === 2) midi = fifth;
    else if (code === 3) midi = approach;
    else if (code === 4) midi = octave;
    else if (code === 5) midi = third;
    const dur = code === 1 && tick % 4 === 0 ? 4 : 2;
    notes.push({
      tick,
      durationTicks: dur,
      midi: clampMidi(midi),
      velocity: 0.62 + (tick === 0 ? 0.12 : 0) * pulse,
      voice: "bass",
    });
  }
}

function addPercussion(
  notes: ScoreNote[],
  session: SessionIdentity,
  percAmt: number,
  rng: ReturnType<typeof createPrng>,
  isFill: boolean,
  mode: ReturnType<typeof modeModifiers>,
  intensity: number,
) {
  if (percAmt < 0.08) return;
  const pattern = session.theme.percPatterns[0]!;
  const hatGain = percAmt * mode.pulse;
  const voiceFor = (kind: PercHitKind): VoiceName => {
    if (kind === "kick") return "kick";
    if (kind === "snare") return "snare";
    if (kind === "hat" || kind === "hatOpen") return "hat";
    return "click";
  };

  const place = (kind: PercHitKind, tick: number, step: number) => {
    if (step <= 0) return;
    const threshold = kind === "hat" ? 0.18 : kind === "kick" ? 0.12 : 0.28;
    if (percAmt < threshold && step < 2) return;
    notes.push({
      tick,
      durationTicks: kind === "kick" ? 3 : 1,
      midi: kind === "kick" ? 36 : kind === "snare" ? 48 : kind === "click" ? 84 : 80,
      velocity: (step >= 2 ? 0.85 : 0.5) * (kind === "hat" ? hatGain : percAmt),
      voice: voiceFor(kind),
    });
  };

  for (let tick = 0; tick < TICKS_PER_BAR; tick++) {
    place("kick", tick, pattern.kick[tick] ?? 0);
    place("snare", tick, pattern.snare[tick] ?? 0);
    place("hat", tick, pattern.hat[tick] ?? 0);
    place("click", tick, pattern.click[tick] ?? 0);
  }

  if (isFill) {
    for (let tick = 12; tick < 16; tick++) {
      if (rng.chance(0.65 + intensity * 0.2)) {
        notes.push({
          tick,
          durationTicks: 1,
          midi: 48 + (tick % 2) * 12,
          velocity: 0.55 + (tick - 12) * 0.08,
          voice: tick % 2 === 0 ? "snare" : "click",
        });
      }
    }
  }

  if (mode.instability > 0.5 && rng.chance(mode.instability * 0.3)) {
    notes.push({
      tick: rng.nextInt(16),
      durationTicks: 1,
      midi: 90,
      velocity: 0.3,
      voice: "click",
    });
  }
}

function addMelody(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  ctx: ComposeContext,
  section: SectionId,
  density: number,
  rng: ReturnType<typeof createPrng>,
) {
  if (section === "INTRO" && density < 0.35) return;
  if (section === "TRANSITION") return;
  if (rng.chance(session.theme.restBias * (1.1 - density))) return;

  const motif = session.motifs[ctx.barIndex % session.motifs.length] ?? session.motifs[0]!;
  const variation = pickVariation(ctx.barIndex, rng);
  const realizedMotif = variation === "prime" ? motif : varyMotif(motif, variation, rng);
  const phraseBar = ctx.barIndex % 4;
  if (phraseBar === 3 && session.theme.restBias > 0.25) return;

  const startTick = phraseBar === 1 ? 2 : 0;
  const register = shiftRegister(session.theme.melodyRegister, ctx.combo, ctx.barIndex);
  const realized = realizeMotif({
    motif: realizedMotif,
    tonicPc: session.tonicPc,
    scale: session.scale,
    chord: voicing,
    register,
    startTick,
    voice: density > 0.7 ? "lead" : "pluck",
    velocity: 0.52 + density * 0.28,
  });

  for (const note of realized) {
    if (note.tick >= TICKS_PER_BAR) continue;
    notes.push(note);
  }

  if (ctx.combo >= 16 && rng.chance(0.4)) {
    const counter = realizeMotif({
      motif: varyMotif(motif, "response", rng),
      tonicPc: session.tonicPc,
      scale: session.scale,
      chord: voicing,
      register: [register[0] + 7, register[1] + 5],
      startTick: 8,
      voice: "bell",
      velocity: 0.32,
    });
    notes.push(...counter.filter((n) => n.tick < TICKS_PER_BAR));
  }
}

function addArp(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  density: number,
  rng: ReturnType<typeof createPrng>,
  combo: number,
  section: SectionId,
) {
  if (density < 0.28) return;
  if (section === "INTRO" && density < 0.4) return;
  const ticks = session.theme.arpTicks;
  const tones = chordTonesMidi(voicing, [session.theme.melodyRegister[0] - 7, session.theme.melodyRegister[1] - 5]);
  if (tones.length === 0) return;
  const rate = combo >= 12 && density > 0.55 ? 1 : 0;
  const used = rate ? ticks : ticks.filter((_, i) => i % 2 === 0 || ticks.length <= 4);
  let dir = 1;
  let idx = rng.nextInt(tones.length);
  for (const tick of used) {
    const midi = tones[idx] ?? tones[0]!;
    notes.push({
      tick,
      durationTicks: 2,
      midi,
      velocity: 0.28 + density * 0.2,
      voice: density > 0.6 ? "pluck" : "bell",
      pan: ((tick % 8) / 8 - 0.5) * 0.35,
    });
    idx += dir;
    if (idx >= tones.length || idx < 0) {
      dir *= -1;
      idx = Math.max(0, Math.min(tones.length - 1, idx + dir));
    }
  }
}

function addPickupEcho(
  notes: ScoreNote[],
  voicing: ChordVoicing,
  session: SessionIdentity,
  contour: number[],
  rng: ReturnType<typeof createPrng>,
) {
  const fragment = contour.slice(-4);
  let tick = 8;
  for (const midi of fragment) {
    let fitted = midi;
    if (!isChordTone(fitted, voicing)) {
      fitted = nearestScaleMidi(fitted, session.tonicPc, session.scale);
    }
    notes.push({
      tick,
      durationTicks: 2,
      midi: clampMidi(fitted),
      velocity: 0.34,
      voice: "bell",
    });
    tick += rng.pick([2, 2, 4]);
    if (tick >= 16) break;
  }
}

function shiftRegister(register: [number, number], combo: number, barIndex: number): [number, number] {
  const comboLift = Math.min(7, Math.floor(combo / 10));
  const cycleLift = barIndex % 32 >= 24 ? 3 : 0;
  return [register[0] + comboLift + cycleLift, register[1] + comboLift + cycleLift];
}

export function choosePickupMidi(options: {
  voicing: ChordVoicing;
  tonicPc: number;
  scale: import("../core/types.ts").ScaleName;
  combo: number;
  strongBeat: boolean;
  rng: ReturnType<typeof createPrng>;
}): number {
  const { voicing, combo, strongBeat, rng } = options;
  const register: [number, number] = combo >= 20 ? [79, 96] : combo >= 8 ? [72, 88] : [67, 84];
  const pool = strongBeat || combo < 4
    ? chordTonesMidi(voicing, register)
    : [
        ...chordTonesMidi(voicing, register),
        nearestScaleMidi(voicing.rootMidi + 2, options.tonicPc, options.scale) + 12,
      ];
  const chosen = pool.length ? rng.pick(pool) : voicing.rootMidi + 12;
  return clampMidi(chosen);
}
