import { createPrng } from "../core/prng.ts";
import { clamp01, lerp } from "../core/pitch.ts";
import type {
  PlanetMusicProfile,
  ScaleName,
  WorldThemeDefinition,
} from "../core/types.ts";
import { CURATED_THEMES } from "../themes/catalog.ts";
import { DURAZNO } from "../themes/durazno.ts";
import { ECLIPSE } from "../themes/eclipse.ts";
import { GLACIAR } from "../themes/glaciar.ts";
import { LAVANDA } from "../themes/lavanda.ts";
import { MENTA } from "../themes/menta.ts";

const BIOME_BASE: Record<PlanetMusicProfile["biome"], WorldThemeDefinition> = {
  ocean: { ...MENTA, id: "menta" },
  tropical: { ...DURAZNO, id: "durazno" },
  desert: { ...DURAZNO, id: "durazno" },
  lava: { ...ECLIPSE, id: "eclipse" },
  glacial: { ...GLACIAR, id: "glaciar" },
  crystal: { ...GLACIAR, id: "glaciar" },
  dead: { ...GLACIAR, id: "glaciar" },
  storm: { ...ECLIPSE, id: "eclipse" },
  mixed: { ...LAVANDA, id: "lavanda" },
};

const MOOD_SCALES: Record<PlanetMusicProfile["mood"], ScaleName[]> = {
  calm: ["lydian", "majorPentatonic", "dorian"],
  hopeful: ["major", "lydian", "mixolydian"],
  mysterious: ["dorian", "lydian", "melodicMinor"],
  tense: ["phrygian", "harmonicMinor", "dorian"],
  dark: ["phrygian", "aeolian", "harmonicMinor"],
  energetic: ["mixolydian", "major", "dorian"],
};

export function mapPlanetProfile(profile: PlanetMusicProfile): WorldThemeDefinition {
  const intensity = clamp01(profile.intensity);
  const temperature = clamp01(profile.temperature);
  const luminosity = clamp01(profile.luminosity);
  const danger = clamp01(profile.danger);
  const anomaly = clamp01(profile.anomaly);

  const base = structuredClone(BIOME_BASE[profile.biome] ?? LAVANDA) as WorldThemeDefinition;
  const rng = createPrng(`planet:${profile.seed}:${profile.biome}:${profile.mood}`);

  const scales = MOOD_SCALES[profile.mood];
  base.scales = [rng.pick(scales), ...scales.filter((s) => s !== scales[0])].slice(0, 3);

  const tempoMin = lerp(64, 96, intensity * 0.6 + (profile.mood === "energetic" ? 0.4 : 0));
  const tempoMax = tempoMin + 8 + danger * 10;
  base.tempoRange = [Math.round(tempoMin), Math.round(tempoMax)];

  base.densityRange = [
    clamp01(0.12 + intensity * 0.3 - (profile.biome === "dead" ? 0.08 : 0)),
    clamp01(0.4 + intensity * 0.5 + danger * 0.15),
  ];
  base.restBias = clamp01(0.18 + (1 - intensity) * 0.3 + (profile.biome === "dead" ? 0.2 : 0));
  base.variationProbability = clamp01(0.22 + anomaly * 0.4);

  base.timbre = {
    ...base.timbre,
    brightness: clamp01(0.25 + luminosity * 0.55),
    padCutoff: lerp(420, 1400, luminosity),
    bassCutoff: lerp(240, 640, temperature),
    noiseAmount: clamp01(0.04 + (profile.biome === "storm" ? 0.18 : 0) + danger * 0.08),
    space: clamp01(0.3 + (1 - intensity) * 0.4 + (profile.biome === "ocean" ? 0.15 : 0)),
    bellInharmonic: clamp01(0.1 + (profile.biome === "crystal" ? 0.35 : 0) + anomaly * 0.2),
  };

  if (profile.biome === "ocean") {
    base.arpTicks = [0, 4, 8, 12];
    base.swing = 0.03;
  } else if (profile.biome === "lava") {
    base.arpTicks = [0, 2, 4, 8, 10, 12];
    base.bassPatterns = ECLIPSE.bassPatterns;
  } else if (profile.biome === "glacial" || profile.biome === "crystal") {
    base.arpTicks = profile.biome === "crystal" ? [0, 4, 8, 12] : [0, 8];
    base.percPatterns = GLACIAR.percPatterns;
  } else if (profile.biome === "dead") {
    base.arpTicks = [0];
    base.cadenceEveryBars = 16;
  } else if (profile.biome === "storm") {
    base.percPatterns = ECLIPSE.percPatterns;
    base.arpTicks = [0, 3, 6, 8, 11, 14];
  }

  if (anomaly > 0.65) {
    base.arpTicks = [0, 3, 5, 8, 11, 13];
    base.swing = rng.nextRange(0, 0.12);
  }

  base.melodyRegister = [
    Math.round(lerp(57, 72, luminosity)),
    Math.round(lerp(76, 93, luminosity)),
  ];
  base.padRegister = [
    Math.round(lerp(43, 55, luminosity)),
    Math.round(lerp(67, 79, luminosity)),
  ];

  return base;
}

export function nearestCuratedTheme(profile: PlanetMusicProfile): keyof typeof CURATED_THEMES {
  if (profile.danger > 0.7 || profile.biome === "lava") return "eclipse";
  if (profile.biome === "glacial" || profile.biome === "crystal" || profile.biome === "dead") return "glaciar";
  if (profile.mood === "mysterious" || profile.anomaly > 0.55 || profile.biome === "mixed") return "lavanda";
  if (profile.mood === "energetic" || profile.biome === "tropical" || profile.biome === "desert") return "durazno";
  return "menta";
}
