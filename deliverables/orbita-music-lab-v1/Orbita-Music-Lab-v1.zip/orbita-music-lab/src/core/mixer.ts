export type Mixer = {
  ctx: AudioContext;
  master: GainNode;
  music: GainNode;
  sfx: GainNode;
  compressor: DynamicsCompressorNode;
  analyser: AnalyserNode;
  musicVolume: number;
  sfxVolume: number;
  musicMuted: boolean;
  sfxMuted: boolean;
  setMusicVolume: (value: number) => void;
  setSfxVolume: (value: number) => void;
  setMusicMuted: (muted: boolean) => void;
  setSfxMuted: (muted: boolean) => void;
  dispose: () => void;
};

function clamp(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

export function createMixer(ctx: AudioContext): Mixer {
  const master = ctx.createGain();
  master.gain.value = 0.72;
  const compressor = ctx.createDynamicsCompressor();
  compressor.threshold.value = -14;
  compressor.knee.value = 12;
  compressor.ratio.value = 3.2;
  compressor.attack.value = 0.008;
  compressor.release.value = 0.22;
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 256;
  analyser.smoothingTimeConstant = 0.8;
  const music = ctx.createGain();
  const sfx = ctx.createGain();
  music.gain.value = 0.85;
  sfx.gain.value = 0.9;
  music.connect(compressor);
  sfx.connect(compressor);
  compressor.connect(analyser);
  analyser.connect(master);
  master.connect(ctx.destination);

  const apply = () => {
    music.gain.setTargetAtTime(mixer.musicMuted ? 0 : mixer.musicVolume * 0.85, ctx.currentTime, 0.03);
    sfx.gain.setTargetAtTime(mixer.sfxMuted ? 0 : mixer.sfxVolume * 0.9, ctx.currentTime, 0.03);
  };

  const mixer: Mixer = {
    ctx,
    master,
    music,
    sfx,
    compressor,
    analyser,
    musicVolume: 0.85,
    sfxVolume: 0.9,
    musicMuted: false,
    sfxMuted: false,
    setMusicVolume(value) {
      mixer.musicVolume = clamp(value);
      apply();
    },
    setSfxVolume(value) {
      mixer.sfxVolume = clamp(value);
      apply();
    },
    setMusicMuted(muted) {
      mixer.musicMuted = muted;
      apply();
    },
    setSfxMuted(muted) {
      mixer.sfxMuted = muted;
      apply();
    },
    dispose() {
      try {
        music.disconnect();
        sfx.disconnect();
        compressor.disconnect();
        analyser.disconnect();
        master.disconnect();
      } catch {
        /* already disconnected */
      }
    },
  };
  return mixer;
}
