import { MAX_VOICES_DEFAULT } from "./types.ts";

export type TrackedVoice = {
  nodes: AudioNode[];
  stopAt: number;
};

export class VoiceManager {
  private voices: TrackedVoice[] = [];
  readonly maxVoices: number;
  scheduledEvents = 0;

  constructor(maxVoices = MAX_VOICES_DEFAULT) {
    this.maxVoices = maxVoices;
  }

  get activeVoices(): number {
    return this.voices.length;
  }

  track(nodes: AudioNode[], stopAt: number) {
    this.voices.push({ nodes, stopAt });
    this.scheduledEvents += 1;
    if (this.voices.length > this.maxVoices) {
      const oldest = this.voices.shift();
      if (oldest) this.stopNow(oldest);
    }
  }

  sweep(now: number) {
    const keep: TrackedVoice[] = [];
    for (const voice of this.voices) {
      if (voice.stopAt <= now) this.disconnect(voice);
      else keep.push(voice);
    }
    this.voices = keep;
  }

  dispose() {
    for (const voice of this.voices) this.stopNow(voice);
    this.voices = [];
    this.scheduledEvents = 0;
  }

  private stopNow(voice: TrackedVoice) {
    for (const node of voice.nodes) {
      try {
        if ("stop" in node && typeof (node as OscillatorNode).stop === "function") {
          (node as OscillatorNode).stop();
        }
      } catch {
        /* already stopped */
      }
    }
    this.disconnect(voice);
  }

  private disconnect(voice: TrackedVoice) {
    for (const node of voice.nodes) {
      try {
        node.disconnect();
      } catch {
        /* already disconnected */
      }
    }
  }
}
